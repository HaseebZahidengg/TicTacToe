﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        char who = 'o';
        int movement = 0;

        public int checkGame()         //Check winner status
        {
            if((b1.Text == b2.Text && b2.Text == b3.Text && b1.Text != "")||
               (b4.Text == b5.Text && b5.Text == b6.Text && b4.Text != "") ||
               (b7.Text == b8.Text && b8.Text == b9.Text && b7.Text != "") ||
               (b1.Text == b4.Text && b4.Text == b7.Text && b1.Text != "") ||
               (b2.Text == b5.Text && b5.Text == b8.Text && b2.Text != "") ||
               (b3.Text == b6.Text && b6.Text == b9.Text && b3.Text != "") ||
               (b1.Text == b5.Text && b5.Text == b9.Text && b1.Text != "") ||
               (b3.Text == b5.Text && b5.Text == b7.Text && b3.Text != ""))
            {
                //MessageBox.Show("Row one done");
                return 1;
            }
            else
            {
                return 0;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            who = 'o';
            movement = 0;
            b1.BackColor = Color.White; b2.BackColor = Color.White; b3.BackColor = Color.White;
            b4.BackColor = Color.White; b5.BackColor = Color.White; b6.BackColor = Color.White;
            b7.BackColor = Color.White; b8.BackColor = Color.White; b9.BackColor = Color.White;

            b1.Text = ""; b2.Text = ""; b3.Text = "";
            b4.Text = ""; b5.Text = ""; b6.Text = "";
            b7.Text = ""; b8.Text = ""; b9.Text = "";
        }

        public void newGame()
        {
            char who = 'o';
            int movement = 0;
            b1.BackColor = Color.White; b2.BackColor = Color.White; b3.BackColor = Color.White;
            b4.BackColor = Color.White; b5.BackColor = Color.White; b6.BackColor = Color.White;
            b7.BackColor = Color.White; b8.BackColor = Color.White; b9.BackColor = Color.White;

            b1.Text = ""; b2.Text = ""; b3.Text = "";
            b4.Text = ""; b5.Text = ""; b6.Text = "";
            b7.Text = ""; b8.Text = ""; b9.Text = "";
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //b1.Text = ""; b2.Text = "";  b3.Text = "";
            //b4.Text = ""; b5.Text = "";  b6.Text = "";
            //b7.Text = ""; b8.Text = "";  b9.Text = "";

        }

        private void button_Click(object sender, EventArgs e)
        {



            Button bt = sender as Button;       //Sender as button is used whenone function is accessed by many elements
            bt.Enabled = true;                  //???
            bt.BackColor = Color.LightGray;
            if (who == 'o')
            {
                bt.Text = "0";
                if (checkGame() == 1)           //Check winner of the game after every turn
                {
                    MessageBox.Show("Player 0 wins the game!");
                }
                if (movement == 8)              //Check if 9 turns are done and there is no winner
                {
                    MessageBox.Show("Draw!");
                }
                who = 'x';
                movement += 1;
            }
            else if (who == 'x')
            {

                bt.Text = "X";

                if (checkGame() == 1)               //Check winner of the game after every turn
                {
                    MessageBox.Show("Player X wins the game!");
                }
                if (movement == 8)                  //Check if 9 turns are done and there is no winner
                {
                    MessageBox.Show("Draw!");
                }

                who = 'o';
                movement += 1;
            }
        }


    }
}
